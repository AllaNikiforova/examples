#!/bin/bash

jar --file=jars/server-1.0-SNAPSHOT.jar --describe-

#java --module-path jars/server-1.0-SNAPSHOT.jar --module server/ru.ser.Server
#java ^
#--module-path jars/server-1.0-SNAPSHOT.jar ^
#--module server/ru.hse.javaprogramming.Main